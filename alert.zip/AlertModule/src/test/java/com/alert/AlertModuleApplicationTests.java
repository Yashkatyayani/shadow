package com.alert;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AlertModuleApplicationTests {

	@Test
	void contextLoads() {
	}

}
