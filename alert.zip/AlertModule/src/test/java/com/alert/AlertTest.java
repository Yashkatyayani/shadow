package com.alert;

import static org.junit.jupiter.api.Assertions.assertEquals;
import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import com.alert.model.Alert;
import com.alert.receive.Receiver;

@SpringBootTest
public class AlertTest {
	
	@Autowired(required=true)
	Receiver receiver;
	
	
	@BeforeAll
    static void setUpBeforeClass() throws Exception {
        System.out.println("Before all testcases");
    }
    

 

    @AfterAll
    static void tearDownAfterClass() throws Exception {
        System.out.println("After all testcases");
    }

 

    @BeforeEach
    void setUp() throws Exception {
        receiver =new Receiver();
        System.out.println("Before each testcases");
    }

 

    @AfterEach
    void tearDown() throws Exception {
        receiver =new Receiver();
        System.out.println("After each testcases");
    }
    @Test
	public void alertHeartRate() {
	 
	 String actual = receiver.generateAlert(new Alert(1,new String("2020-12-12"),50,null,null));
	 String expected = "Heart Rate of patient1 is LOW!";
	 assertEquals(expected,actual);
    }
    public void alertBloodOxygen() {
	 String actual = receiver.generateAlert(new Alert(1,new String("2020-12-12"),null,74,null));
	 String expected = "Blood Oxygen level for patient is LOW!";
	 assertEquals(expected,actual);
    }
    public void alertBloodPressure() {
     String actual = receiver.generateAlert(new Alert(2,new String("2020-12-12"),null,null,150));
     String expected = "Blood Pressure of patient2 is HIGH!";
     assertEquals(expected,actual);
    }
    
}

