package com.alert.model;

public class Alert {
	private Integer patientid;
    private String timestamp;
    private Integer heartrate;
    private Integer bloodpressure;
    private Integer bloodoxygenlevel;
	
    public Alert(Integer patientid, String timestamp, Integer heartrate, Integer bloodpressure,
			Integer bloodoxygenlevel) {
		super();
		this.patientid = patientid;
		this.timestamp = timestamp;
		this.heartrate = heartrate;
		this.bloodpressure = bloodpressure;
		this.bloodoxygenlevel = bloodoxygenlevel;
	}
	public Alert() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Integer getPatientid() {
		return patientid;
	}
	public void setPatientid(Integer patientid) {
		this.patientid = patientid;
	}
	public String getTimestamp() {
		return timestamp;
	}
	public void setTimestamp(String timestamp) {
		this.timestamp = timestamp;
	}
	public Integer getHeartrate() {
		return heartrate;
	}
	public void setHeartrate(Integer heartrate) {
		this.heartrate = heartrate;
	}
	public Integer getBloodpressure() {
		return bloodpressure;
	}
	public void setBloodpressure(Integer bloodpressure) {
		this.bloodpressure = bloodpressure;
	}
	public Integer getBloodoxygenlevel() {
		return bloodoxygenlevel;
	}
	public void setBloodoxygenlevel(Integer bloodoxygenlevel) {
		this.bloodoxygenlevel = bloodoxygenlevel;
	}
	@Override
	public String toString() {
		return "Alert [patientid=" + patientid + ", timestamp=" + timestamp + ", heartrate=" + heartrate
				+ ", bloodpressure=" + bloodpressure + ", bloodoxygenlevel=" + bloodoxygenlevel + "]";
	}
    
}
