package com.alert.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.mvc.method.annotation.SseEmitter;

import com.alert.model.Alert;
import com.alert.repository.AlertRepository;

import reactor.core.publisher.Flux;

@RestController
public class AlertController {
	SseEmitter sseEmitter = new SseEmitter();
	@Autowired
    private AlertRepository alertRepository;

    @GetMapping(path = "/comment/stream", 
        produces = MediaType.TEXT_EVENT_STREAM_VALUE)
    public Flux<Alert> feed() {
        return this.alertRepository.findAll();
    }
}
