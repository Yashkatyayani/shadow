 package com.alert.receive;

import org.springframework.amqp.core.Message;
import org.springframework.amqp.rabbit.listener.api.ChannelAwareMessageListener;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestTemplate;

import com.alert.controller.AlertController;
import com.alert.model.Alert;
import com.alert.model.Send;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.rabbitmq.client.Channel;
@Component
public class Receiver implements ChannelAwareMessageListener{
	AlertController controller= new AlertController();
	public Receiver() {
		// TODO Auto-generated constructor stub
	}

	@Override
	public void onMessage(Message message, Channel channel) throws Exception {
		// TODO Auto-generated method stub
		byte[] body = message.getBody();
		  String receive=new String(body); 
		  Alert obj =  new ObjectMapper().readValue(receive, Alert.class); 
		  System.out.println("Obj: "+obj);
		  
		  String result= generateAlert(obj);
		  
			  try {
			String query = "http://localhost:8080/dispatch";
			
			RestTemplate restTemplate = new RestTemplate();
			HttpHeaders headers = new HttpHeaders();
			headers.setContentType(MediaType.APPLICATION_JSON);
			HttpEntity<Object> entity = new HttpEntity<Object>(obj,headers);
			Send object=new Send(result);
			Send answer = restTemplate.postForObject(query,object, Send.class);
			System.out.println(answer);
		} 
		  catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
			  
		  channel.basicAck(message.getMessageProperties().getDeliveryTag(), false);
	}
	public String generateAlert(Alert obj ) {
		
		String result="";
		if(obj.getHeartrate() != null) {
			  
			  if(obj.getHeartrate() < 60)
			  {
				  result ="Heart Rate of patient" +obj.getPatientid() +" is LOW!";
			  }
			  if (obj.getHeartrate() > 100)
			  {
				  result = "Heart Rate of patient" +obj.getPatientid()  +" is HIGH!";
			  }
		  }
		  
		  
		  if(obj.getBloodoxygenlevel()!= null) {
			  
			  if(obj.getBloodoxygenlevel() < 75)
			  {
				  result ="Blood Oxygen level of patient" +obj.getPatientid() + " is LOW!";
			  }
			  if(obj.getBloodoxygenlevel() > 100)
			  {
				  result ="Blood Oxygen level of patient" +obj.getPatientid() + " is Invalid!";
			  }
			  }
		  if(obj.getBloodpressure() != null) {
			  if(obj.getBloodpressure() < 90)
			  {
				  result = "Blood Pressure of patient" +obj.getPatientid() + " is LOW!" ;
			  }
			  if(obj.getBloodpressure() > 140)
			  {
				  result = "Blood Pressure of patient" +obj.getPatientid() + " is HIGH!" ;
			  }
		  }
		  return result;
	}

}
