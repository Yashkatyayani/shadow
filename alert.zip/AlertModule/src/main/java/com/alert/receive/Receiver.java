package com.alert.receive;

import org.springframework.amqp.core.Message;
import org.springframework.amqp.rabbit.listener.api.ChannelAwareMessageListener;
import org.springframework.boot.autoconfigure.gson.GsonAutoConfiguration;
import org.springframework.boot.json.GsonJsonParser;
import org.springframework.stereotype.Component;

import com.alert.model.Alert;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.rabbitmq.client.Channel;
@Component
public class Receiver implements ChannelAwareMessageListener{

	public Receiver() {
		// TODO Auto-generated constructor stub
	}

	@Override
	public void onMessage(Message message, Channel channel) throws Exception {
		// TODO Auto-generated method stub
		byte[] body = message.getBody();
		  String receive=new String(body); 
		  Alert obj =  new ObjectMapper().readValue(receive, Alert.class); 
		  System.out.println(obj);
		  channel.basicAck(message.getMessageProperties().getDeliveryTag(), false);
	}

}
