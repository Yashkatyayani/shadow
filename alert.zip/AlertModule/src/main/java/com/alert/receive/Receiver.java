package com.alert.receive;

import java.io.IOException;
import java.io.OutputStreamWriter;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.ProtocolException;
import java.net.URL;

import org.springframework.amqp.core.Message;
import org.springframework.amqp.rabbit.listener.api.ChannelAwareMessageListener;
import org.springframework.boot.autoconfigure.gson.GsonAutoConfiguration;
import org.springframework.boot.json.GsonJsonParser;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestTemplate;

import com.alert.controller.AlertController;
import com.alert.model.Alert;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.rabbitmq.client.Channel;
@Component
public class Receiver implements ChannelAwareMessageListener{
	AlertController controller= new AlertController();
	public Receiver() {
		// TODO Auto-generated constructor stub
	}

	@Override
	public void onMessage(Message message, Channel channel) throws Exception {
		// TODO Auto-generated method stub
		byte[] body = message.getBody();
		  String receive=new String(body); 
		  Alert obj =  new ObjectMapper().readValue(receive, Alert.class); 
		  System.out.println("Obj: "+obj);
		  try {
			String query = "http://192.168.91.110:8080/dispatch";
			
			RestTemplate restTemplate = new RestTemplate();
			HttpHeaders headers = new HttpHeaders();
			headers.setContentType(MediaType.APPLICATION_JSON);
		
			HttpEntity<Object> entity = new HttpEntity<Object>(obj,headers);
			
			Alert answer = restTemplate.postForObject(query, entity, Alert.class);
			System.out.println(answer);
		} 
		  catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
			  
		  channel.basicAck(message.getMessageProperties().getDeliveryTag(), false);
	}

}
