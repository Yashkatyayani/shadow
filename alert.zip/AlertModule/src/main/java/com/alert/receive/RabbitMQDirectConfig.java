package com.alert.receive;

import org.springframework.amqp.core.AcknowledgeMode;
import org.springframework.amqp.core.AmqpTemplate;
import org.springframework.amqp.core.Binding;
import org.springframework.amqp.core.BindingBuilder;
import org.springframework.amqp.core.DirectExchange;
import org.springframework.amqp.core.Queue;
import org.springframework.amqp.rabbit.connection.CachingConnectionFactory;
import org.springframework.amqp.rabbit.connection.ConnectionFactory;
import org.springframework.amqp.rabbit.core.RabbitTemplate;
import org.springframework.amqp.rabbit.listener.MessageListenerContainer;
import org.springframework.amqp.rabbit.listener.SimpleMessageListenerContainer;
import org.springframework.amqp.rabbit.listener.adapter.MessageListenerAdapter;
import org.springframework.amqp.support.converter.Jackson2JsonMessageConverter;
import org.springframework.amqp.support.converter.MessageConverter;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;



@Configuration
public class RabbitMQDirectConfig {

	 // To listen data continuously from server respectively 
	public static final String  Blood_Pressure = "Blood_Pressure_server";
	public static final String  Blood_oxygen_level = "Blood_oxygen_level_server";
	public static final String  Heart_rate = "Heart_rate_server";

	@Bean
	Queue Blood_Pressure() {
		return new Queue("Blood_Pressure_server", false);
	}

	@Bean
	Queue Blood_oxygen_level() {
		return new Queue("Blood_oxygen_level_server", false);
	}

	@Bean
	Queue Heart_rate() {
		return new Queue("Heart_rate_server", false);
	}

	@Bean
	DirectExchange exchange() {
		return new DirectExchange("direct-exchange");
	}

	@Bean
	Binding Blood_PressureBinding(Queue Blood_Pressure, DirectExchange exchange) {
		return BindingBuilder.bind(Blood_Pressure).to(exchange).with("Blood_Pressure_server");
	}

	@Bean
	Binding OxygenBinding(Queue Blood_oxygen_level, DirectExchange exchange) {
		return BindingBuilder.bind(Blood_oxygen_level).to(exchange).with("Blood_oxygen_level_server");
	}

	@Bean
	Binding HeartBinding(Queue Heart_rate, DirectExchange exchange) {
		return BindingBuilder.bind(Heart_rate).to(exchange).with("Heart_rate_server");
	}
	@Bean
	SimpleMessageListenerContainer container(ConnectionFactory connectionFactory,
			MessageListenerAdapter listenerAdapter)
	{
		SimpleMessageListenerContainer container = new SimpleMessageListenerContainer();
		container.setConnectionFactory(connectionFactory);
		container.setAcknowledgeMode(AcknowledgeMode.MANUAL);
		container.setQueueNames(Blood_Pressure);
		container.setMessageListener(listenerAdapter);
		return container;
	}
	@Bean
	SimpleMessageListenerContainer container1(ConnectionFactory connectionFactory,
			MessageListenerAdapter listenerAdapter)
	{
		SimpleMessageListenerContainer container = new SimpleMessageListenerContainer();
		container.setConnectionFactory(connectionFactory);
		container.setAcknowledgeMode(AcknowledgeMode.MANUAL);
		//container.setQueueNames(Blood_Pressure);
		container.setQueueNames(Blood_oxygen_level);
	//	container.setQueueNames(Heart_rate);
		container.setMessageListener(listenerAdapter);
		return container;
	}
	@Bean
	SimpleMessageListenerContainer container2(ConnectionFactory connectionFactory,
			MessageListenerAdapter listenerAdapter)
	{
		SimpleMessageListenerContainer container = new SimpleMessageListenerContainer();
		container.setConnectionFactory(connectionFactory);
		container.setAcknowledgeMode(AcknowledgeMode.MANUAL);
		container.setQueueNames(Heart_rate);
		container.setMessageListener(listenerAdapter);
		return container;
	}
	@Bean
	public ConnectionFactory connectionFactory()
	{
		CachingConnectionFactory connectionFactory = new CachingConnectionFactory(
                "192.168.91.187");
        connectionFactory.setPort(5672);
        connectionFactory.setVirtualHost("DeMoHost");
        connectionFactory.setUsername("userdemo");
        connectionFactory.setPassword("userdemo");
        return connectionFactory;
	}
	@Bean
	MessageListenerAdapter listenerAdapter(Receiver consumer)
	{
		return new MessageListenerAdapter(consumer, "receiveMessage");
	}

}
